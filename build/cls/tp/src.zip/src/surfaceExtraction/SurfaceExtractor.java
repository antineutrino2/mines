package surfaceExtraction;

import java.util.Scanner;
import java.io. *;
import edu.mines.jtk.mosaic. *;
import edu.mines.jtk.awt. *;
import edu.mines.jtk.dsp. *;
import edu.mines.jtk.io. *;
import edu.mines.jtk.sgl. *;
import edu.mines.jtk.util. *;
import edu.mines.jtk.interp. *;
import static edu.mines.jtk.util.ArrayMath.*;
public class SurfaceExtractor {
  
  public void setWeights(double w1, double w2){
    _weight1 = (float)w1;
    _weight2 = (float)w2;
  }
  
  public void setSmoothings(double s1, double s2){
    _sigma1 = (float)s1;
    _sigma2 = (float)s2;
  }
  
  public void setCG(double small, int niter){
    _small = (float) small;
    _niter = niter;
  }
  
  public void setExternalIterations(int niter){
    _exniter = niter;
  }
  
  // Initializes a surface using the control points
  public float[][] surfaceInitialization(int n1, int n2, float lmt, float[][] cp){
    float[][] surf = new float[n2][n1]; 
    int n = cp.length; 
    ThinPlateSpline2 tps = new ThinPlateSpline2(n1,n2,cp);
    if (n==1){surf=tps.horizontalSurface();}
    else {
	  ThinPlateSpline2.Coefficients cfs = tps.coefficientsFromPoints();
	  surf = cfs.interpolation();
      }
    for (int i2=0; i2<n2; i2++){
      for (int i1=0; i1<n1; i1++){
        if (surf[i2][i1]<0.f){surf[i2][i1]=0.f;}
        if (surf[i2][i1]>lmt){surf[i2][i1]=lmt;}
      }
    }
    return surf;
  }
  
  // Updates the surface using the seismic normal vectors and control points.
  public float[][] surfaceUpdateFromSlopes
    (float[][][] u1, float[][][] u2, float[][][] u3, float[][] surf, float[][] cp, float lmt, float[][] Ipx, int yt)
  {	
	int n1 = surf[0].length; int n2 = surf.length; int nz = u1[0][0].length;
	float[][] b = new float[n2][n1]; float[][] h = new float[2 ][n2];
	Sampling sy1 = new Sampling(nz,1.,0.); Sampling sx1 = new Sampling(n2,1.,0.); 
	for (int k=0; k<n2; k++){h[0][k]=(float)k; h[1][k] = surf[k][yt];}
	plotFrame(Ipx,h,sy1,sx1,"Iteration "+0,"amplitude");
	System.out.println("Surface updating using seismic normal vectors and control points:");
	for (int n=1; n<=_exniter; n++){
          System.out.println(" Iteration "+n+"......");
          float[][] p = new float[n2][n1]; float[][] q = new float[n2][n1];
	  VecArrayFloat2 vb = new VecArrayFloat2(b);
	  VecArrayFloat2 vsurf = new VecArrayFloat2(surf);
	  Smoother2 smoother2 = new Smoother2(_sigma1, _sigma2);
	  A2 a2 = new A2(smoother2, _weight1);
	  CgSolver cs = new CgSolver(_small, _niter);
	  vb.zero();
	  computepq(u1,u2,u3,surf,p,q);
	  makeRhs(p,q,b);
	  smoother2.applyTranspose(b);
	  cs.solve(a2, vb, vsurf);
	  surf = vsurf.getArray();
	  smoother2.apply(surf);
	  surfaceCorrection(lmt,surf,cp);
	  //_niter +=20;
	  for (int k=0; k<n2; k++){h[0][k]=(float)k; h[1][k] = surf[k][yt];}
	  String title = "Iteration " + n;
	  plotFrame(Ipx,h,sy1,sx1,title,"amplitude");
    }
	return surf;
  }
  // Refines the surface using the active-surface method that honors amplitudes.
  //public void surfaceRefineFromAmplitudes(){
  //}
  
  private static class A2 implements CgSolver.A{
	A2(Smoother2 s2, float mu){_s2=s2; _mu=(double)mu;}  
    public void apply(Vec vx, Vec vy){
	  VecArrayFloat2 v2x = (VecArrayFloat2) vx;
	  VecArrayFloat2 v2y = (VecArrayFloat2) vy;
	  VecArrayFloat2 v2z = v2x.clone();
	  float[][] z = v2z.getArray();
	  float[][] y = v2y.getArray();
	  int n1 = y[0].length; int n2 = y.length;
	  float[][] yy = new float[n2][n1];
	  VecArrayFloat2 v2yy = new VecArrayFloat2(yy);
	  v2y.zero();
	  _s2.apply(z);
	  laplacian(z,y);
	  laplacian(y,yy);//bilaplacian operator
	  v2y.add(1.0,v2yy,_mu);//-(fxx+fyy)+mu*(fxxxx+fyyyy+2fxxyy)
	  _s2.applyTranspose(y);
	}
	private double _mu;
	private Smoother2 _s2;
  }
  
  // Smoother used as a preconditioner 
  private static class Smoother2{
	public Smoother2(float sigma1, float sigma2){
	  _sigma1=sigma1;
	  _sigma2=sigma2;
	}
	public void apply(float[][] x){
	  smooth2(_sigma2,x);
	  smooth1(_sigma1,x);
	}
	public void applyTranspose(float[][] x){
	  smooth1(_sigma1,x);
	  smooth2(_sigma2,x);
	}
    private float _sigma1, _sigma2;  
  }
 
  // Smoothing for dimension 1
  private static void smooth1(float sigma, float[][] x){
    if (sigma<1.0f)
      return;
    float c = 0.5f*sigma*sigma;
    int n1 = x[0].length;
    int n2 = x.length;
    float[] xt = zerofloat(n1);
    float[] yt = zerofloat(n1);
    LocalSmoothingFilter lsf = new LocalSmoothingFilter();
    for (int i2=0; i2<n2; ++i2) {
      for (int i1=0; i1<n1; ++i1)
        xt[i1] = x[i2][i1];
      lsf.apply(c,xt,yt);
      for (int i1=0; i1<n1; ++i1)
        x[i2][i1] = yt[i1];
    }
  }
  // Smoothing for dimension 2
  private static void smooth2(float sigma, float[][] x){
    if (sigma<1.0f)
      return;
    float c = 0.5f*sigma*sigma;
    int n1 = x[0].length;
    int n2 = x.length;
    float[] xt = zerofloat(n2);
    float[] yt = zerofloat(n2);
    LocalSmoothingFilter lsf = new LocalSmoothingFilter();
    for (int i1=0; i1<n1; ++i1) {
      for (int i2=0; i2<n2; ++i2)
        xt[i2] = x[i2][i1];
      lsf.apply(c,xt,yt);
      for (int i2=0; i2<n2; ++i2)
        x[i2][i1] = yt[i2];
    }
  }
  
  // Discrete negative Laplacian operator with 5-point stencil.
  private static void laplacian(float[][] x, float[][] y){
    int n1 = x[0].length;
    int n2 = x.length;
    for (int i2=0; i2<n2; ++i2) {
      int m2 = (i2>0)?i2-1:0;
      for (int i1=0; i1<n1; ++i1) {
        int m1 = (i1>0)?i1-1:0;
        float x1 = x[i2][i1]-x[i2][m1];
        float x2 = x[i2][i1]-x[m2][i1];
        y[i2][i1] += x1+x2;
        y[i2][m1] -= x1;
        y[m2][i1] -= x2;
      }
    }
  }
  
  //private static void makeRhs
  private static void makeRhs(float[][] p, float[][] q, float[][] y) {
    int n1 = y[0].length;
    int n2 = y.length;
    for (int i2=1; i2<n2-1; ++i2) {
      for (int i1=1; i1<n1-1; ++i1) {
		y[i2][i1]=0.5f*(-q[i2][i1+1]+q[i2][i1-1]-p[i2+1][i1]+p[i2-1][i1]);
      }
    }
    for (int i2=0; i2<n2; ++i2){
	  y[i2][0   ] += -q[i2][0   ];
	  y[i2][n1-1] +=  q[i2][n1-1];  
	}
	for (int i1=0; i1<n1; ++i1){
	  y[0   ][i1] += -p[0   ][i1];
	  y[n2-1][i1] +=  p[n2-1][i1];
	}
  }
  
  
  private void surfaceCorrection(float lmt, float[][] surf, float[][] cp){
    int n1 = surf[0].length; int n2 = surf.length; int n = cp.length;
    float[][] cor = new float[n2][n1];
    float[][] dcp = arrayClone(cp);
	for (int i=0; i<n; i++){
	  int i1c = (int) dcp[i][0]; int i2c = (int) dcp[i][1];
	  dcp[i][2] -= surf[i2c][i1c];
	}
	ThinPlateSpline2 tps = new ThinPlateSpline2(n1,n2,dcp);
	if (n==1){cor=tps.horizontalSurface();}
	else{
	  ThinPlateSpline2.Coefficients cfs = tps.coefficientsFromPoints();
	  cor = cfs.interpolation();
	}
	for (int i2=0; i2<n2; i2++){
	  for (int i1=0; i1<n1; i1++){
	    surf[i2][i1] += cor[i2][i1];
	    if (surf[i2][i1]<0.0f){surf[i2][i1]=0.0f;}
	    if (surf[i2][i1]>lmt){surf[i2][i1]=lmt;}
	  }
	}
  }

  
  private static void computepq(float[][][] u1, float[][][] u2, float[][][] u3, float[][] surf, float[][] p, float[][] q){
    int n2 = surf.length; int n1 = surf[0].length;
    for (int i2=0; i2<n2; i2++){
	  for (int i1=0; i1<n1; i1++){
	    int z = Math.round(surf[i2][i1]);
	    p[i2][i1] = -u3[i2][i1][z]/u1[i2][i1][z];
	    q[i2][i1] = -u2[i2][i1][z]/u1[i2][i1][z];
	  }
	}
  }

  public static void plotFrame(float[][] f,float[][] h,Sampling sx1, Sampling sy1,String title, String cbar){
    PlotPanel.Orientation orientation = PlotPanel.Orientation.X1DOWN_X2RIGHT;
    PlotPanel panel = new PlotPanel(2,1,orientation);
    PixelsView pxv0 = panel.addPixels(0,0,sx1,sy1,f);
    pxv0.setColorModel(ColorMap.GRAY);
    PixelsView pxv = panel.addPixels(1,0,sx1,sy1,f);
    pxv.setColorModel(ColorMap.GRAY);
    PointsView ptv = panel.addPoints(1,0,h[1],h[0]);
    ptv.setStyle("r-");
    panel.setVLabel("Time(sample)");
    panel.setHLabel("Inline(sample)");
    panel.addColorBar("Amplitude");
    Mosaic moc = panel.getMosaic();
    PlotFrame frame = new PlotFrame(panel);
    frame.setDefaultCloseOperation(PlotFrame.EXIT_ON_CLOSE);
    int type = 1;
    if (type==0) {
	  frame.setFontSize(24);//Graphic with 24-pt font.
	  panel.setTitle(title);
	} else if (type==1) {
	  frame.setFontSizeForPrint(5.5,240);//Graphic for print.
	  panel.setTitle(title);	
	} else if (type==2) {
	  frame.setFontSizeForSlide(1,1);
	  //panel.setTitle(title);
	}
    frame.setBounds(100,100,1000,600);
    frame.setVisible(true);
  }
  
  public static float[][] arrayClone(float[][] a){
    int ny = a.length; int nx = a[0].length;
    float[][] b = new float[ny][nx];
    for (int i=0; i<ny; i++){
	  for (int j=0; j<nx; j++){
	    b[i][j] = a[i][j];
	  }
	}
	return b;
  }	
  ///////////////////////////////////////////////////////////////////////////
  // private

  private float _weight1 = 0.5f; // (fxx+fyy)-weight1*(fxxxx+2fxxyy+fyyyy)=px+qy
  private float _weight2 = 0.010f; // (fxxxx+2fxxyy+fyyyy)+weight2*(dA/dz)=0
  private float _sigma1 = 6.0f; // precon smoothing extent for 1st dim
  private float _sigma2 = 6.0f; // precon smoothing extent for 2nd dim
  private float _small = 0.01f; // stop CG iterations if residuals small
  private int _niter = 300; // maximum number of CG iterations
  private int _exniter = 10; // external iterations of surface updating
  
}
